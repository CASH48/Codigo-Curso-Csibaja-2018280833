package clases;
public class Operaciones {
    public Operaciones(){} 
    public int suma(int valor1, int valor2){
        return valor1 + valor2;
    }
    public int resta(int valor1, int valor2){
        return valor1 - valor2;
    }
    public int multiplicacion(int valor1, int valor2){
        return valor1 * valor2;
    }
    public double division(int valor1, int valor2){
        return valor1 / valor2;
    }
}

